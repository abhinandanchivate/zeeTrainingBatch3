//
//  ViewController.swift
//  PageControlApp
//
//  Created by Naga Murali Akula on 20/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var pc1: UIPageControl!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func click1() {
        
        let pagevalue: Int = pc1.currentPage
            
        if pagevalue == 0 {
            
            self.view.backgroundColor = .yellow
            
        } else if pagevalue == 1 {
            self.view.backgroundColor = .blue
            
        }
        else if pagevalue == 2 {
            
            self.view.backgroundColor = .cyan
        }
        else {
            
            self.view.backgroundColor = .orange
        }
        
    }


}

