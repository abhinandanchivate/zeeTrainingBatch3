//
//  ViewController.swift
//  SliderAndImageViewApp
//
//  Created by Naga Murali Akula on 20/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var slider1: UISlider!
    @IBOutlet var iv1: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func sliderMove() {
        
        let i: Float = slider1.value
        iv1.alpha = CGFloat(i)
    }


}

