//
//  ViewController.swift
//  SegmentedControlCodingApp
//
//  Created by Naga Murali Akula on 20/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    var sc1: UISegmentedControl!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // segmented control code
        
        let segmentNames = ["Orange", "White", "Green"]
        
        sc1 = UISegmentedControl(items: segmentNames)
        
        sc1.frame = CGRect(x: 30, y: 250, width: 350, height: 40)
        
        sc1.selectedSegmentTintColor = .red
        sc1.backgroundColor = .yellow
        
        sc1.addTarget(self, action: #selector(click1), for: .valueChanged)
        
        self.view.addSubview(sc1)
        
        
        
        
    }
    
    @objc func click1() {
       
        let indexvalue: Int = sc1.selectedSegmentIndex
        
        if indexvalue == 0 {
            
            self.view.backgroundColor = .orange
        }
        else if indexvalue == 1
        {
            self.view.backgroundColor = .white
        }
        else {
            self.view.backgroundColor = .green
            
        }
        
    }


}

