//
//  ViewController.swift
//  PageControlCodingApp
//
//  Created by Naga Murali Akula on 20/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    var pc1: UIPageControl!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        // page control code
        
        pc1 = UIPageControl()
        
        pc1.frame = CGRect(x: 30, y: 200, width: 180, height: 50)
        
        pc1.backgroundColor = .yellow
        pc1.currentPageIndicatorTintColor = .red
        pc1.pageIndicatorTintColor = .black
        
        pc1.currentPage = 0
        pc1.numberOfPages = 4
        
        pc1.addTarget(self, action: #selector(click1), for: .valueChanged)
        
        self.view.addSubview(pc1)
        
        
    }

    
    @objc func click1() {
        
        let pagevalue: Int = pc1.currentPage
            
        if pagevalue == 0 {
            
            self.view.backgroundColor = .yellow
            
        } else if pagevalue == 1 {
            self.view.backgroundColor = .blue
            
        }
        else if pagevalue == 2 {
            
            self.view.backgroundColor = .cyan
        }
        else {
            
            self.view.backgroundColor = .orange
        }
        
    }

}

