//
//  ViewController.swift
//  SwitchApp
//
//  Created by Naga Murali Akula on 20/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var switch1: UISwitch!
    @IBOutlet var label1: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func switch1Click() {
        
        
        if switch1.isOn {
            
            label1.text = "Switch is in on State"
            
            self.view.backgroundColor = .orange
            
            
        }
        
        else {
            
            label1.text = "Switch is in Off State"
            
            self.view.backgroundColor = .green
        }
        
    }


}

