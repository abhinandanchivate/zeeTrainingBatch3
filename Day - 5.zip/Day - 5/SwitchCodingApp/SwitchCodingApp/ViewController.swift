//
//  ViewController.swift
//  SwitchCodingApp
//
//  Created by Naga Murali Akula on 20/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    var s1: UISwitch!
    var label1: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        // switch code
        
        s1 = UISwitch()
        
        s1.frame = CGRect(x: 200, y: 250, width: 150, height: 40)
        
        s1.isOn = false
        s1.onTintColor = .yellow
        s1.thumbTintColor = .black
        
        s1.addTarget(self, action: #selector(click1), for: .valueChanged)
        
        self.view.addSubview(s1)
        
        // label code
        
        label1 = UILabel()
        
        label1.frame = CGRect(x: 100, y: 350, width: 200, height: 40)
        
        label1.textColor = .white
        label1.backgroundColor = .black
        label1.textAlignment = .center
        
        self.view.addSubview(label1)
        
    }
    
    @objc func click1() {
        
        if s1.isOn {
            
            label1.text = "Switch is in on State"
            self.view.backgroundColor = .orange
            
            
        }
        
        else {
            
            label1.text = "Switch is in Off State"
            self.view.backgroundColor = .green
        }
        
        
    }
}

