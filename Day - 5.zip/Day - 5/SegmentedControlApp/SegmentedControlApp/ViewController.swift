//
//  ViewController.swift
//  SegmentedControlApp
//
//  Created by Naga Murali Akula on 20/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var sc1: UISegmentedControl!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func click1() {
        
        let indexvalue: Int = sc1.selectedSegmentIndex
        
        if indexvalue == 0 {
            
            self.view.backgroundColor = .orange
        }
        else if indexvalue == 1
        {
            self.view.backgroundColor = .white
        }
        else {
            self.view.backgroundColor = .green
            
        }
    }


}

