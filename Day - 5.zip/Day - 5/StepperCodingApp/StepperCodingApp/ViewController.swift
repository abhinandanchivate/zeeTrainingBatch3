//
//  ViewController.swift
//  StepperCodingApp
//
//  Created by Naga Murali Akula on 20/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    var s1: UIStepper!
    var label1: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // stepper code
        
        s1 = UIStepper()
        
        s1.frame = CGRect(x: 150, y: 200, width: 180, height: 40)
        
        s1.backgroundColor = .cyan
        s1.stepValue = 2
        s1.minimumValue = 0
        s1.maximumValue = 20
        s1.value = 0
        s1.isContinuous = true
        s1.autorepeat = true
        s1.wraps = true
        s1.addTarget(self, action: #selector(click), for: .valueChanged)
        self.view.addSubview(s1)
        
        
        // label code
        
        label1 = UILabel()
        
        label1.frame = CGRect(x: 150, y: 300, width: 100, height: 40)
        
        label1.textAlignment = .center
        label1.backgroundColor = .black
        label1.textColor = .white
        
        
        self.view.addSubview(label1)
        
    }
    
    @objc func click() {
        
        let i: Int = Int(s1.value)
        
        label1.text = "\(i)"
    }


}

