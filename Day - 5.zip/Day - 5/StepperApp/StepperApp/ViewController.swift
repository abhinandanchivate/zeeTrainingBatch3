//
//  ViewController.swift
//  StepperApp
//
//  Created by Naga Murali Akula on 20/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var s1: UIStepper!
    @IBOutlet var label1: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    
    @IBAction func click1() {
        
        let i: Int = Int(s1.value)
        
        label1.text = "\(i)"
        
    }


}

