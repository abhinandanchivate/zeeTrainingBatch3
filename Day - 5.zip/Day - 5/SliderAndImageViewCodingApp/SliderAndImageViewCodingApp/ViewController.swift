//
//  ViewController.swift
//  SliderAndImageViewCodingApp
//
//  Created by Naga Murali Akula on 20/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    var iv1: UIImageView!
    var s1: UISlider!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // imageview code
        
        iv1 = UIImageView()
        
        iv1.frame = CGRect(x: 110, y: 200, width: 200 , height: 200)

        iv1.contentMode = .scaleAspectFit
        iv1.image = UIImage(named: "1.jpg")
        iv1.backgroundColor = .black
        
        self.view.addSubview(iv1)
        
        // slider Code

        s1 = UISlider()
        
        s1.frame = CGRect(x: 110, y: 500, width: 180, height: 40)
        
        s1.value = 0.5
        s1.minimumValue = 0
        s1.maximumValue = 1
        s1.minimumTrackTintColor = .yellow
        s1.maximumTrackTintColor = .black
        s1.thumbTintColor = .red
        
        s1.addTarget(self, action: #selector(sliderMove), for: .valueChanged)
        
        self.view.addSubview(s1)
        
        
    }
    
    @objc func sliderMove() {
        
        let i: Float = s1.value
        iv1.alpha = CGFloat(i)
    }


}

